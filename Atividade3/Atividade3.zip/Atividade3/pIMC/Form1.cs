﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pIMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        float peso;
        float altura;
        float imc;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtPesoAtual_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            peso = float.Parse(txtPesoAtual.Text);
            altura = float.Parse(txtAltura.Text);
            imc = peso / (altura * altura);
            txtIMC.Text = imc.ToString();

            if(imc < 18.5)
            {
                MessageBox.Show("Magreza");

            } else if (imc <= 24.9)
            {
                MessageBox.Show("Normal");

            } else if (imc <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            } else if (imc <= 39.9)
            {
                MessageBox.Show("Obesidade");
            } else
            {
                MessageBox.Show("Obesidade Grave!");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPesoAtual.Text = string.Empty;
            txtAltura.Text = string.Empty;
            txtIMC.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair?", "Saída", MessageBoxButtons.YesNo,
               MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
