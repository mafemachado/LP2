﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] Nome = new string[10];
            int[] qtd = new int[10];
            for (int i = 0; i < Nome.Length; i++)
            {
                Nome[i] = Interaction.InputBox($"Digite o {i + 1} nome", "Entrada de Dados");
                qtd[i] = Nome[i].Replace(" ", "").Length;
                list.Items.Add($"Nome: {Nome[i]} quantidade: {qtd[i]}");
            }

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
