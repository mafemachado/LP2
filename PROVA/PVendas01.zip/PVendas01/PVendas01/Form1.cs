﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e, double sum)
        {
            Vendas.Items.Clear();
            double[,] mes = new double[3, 4];
            double[] semana = new double[4];
            double aux;
            double soma = 0;

            for (int i = 0; i < mes.GetLength(0); i++)
            {
                for (int j = 0; j < semana.GetLength(0); j++)

                {
                    if (!double.TryParse(Interaction.InputBox($"Total Vendido na Semana {i + 1}: "), out aux))
                    {
                        MessageBox.Show("Entrada inválida");
                        j--;
                    }
                      if (aux >= 0 && aux <= 10)
                      {
                        mes[i, j] = aux;
                        soma += mes[i, j];

                          }
                      for (int z = 0; z < mes.GetLength(0); i++)
                         {
                        MessageBox.Show($"Total do mês {i + 1} Semana{semana[i].ToString("F2")}");
                        }
                        MessageBox.Show($"Total Mês{sum}");
                }
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
 }
    
