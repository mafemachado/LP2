﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume;
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            txtRaio.Text = string.Empty;
            txtAltura.Text = string.Empty;
            txtVolume.Text = string.Empty;
        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura inválido!");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("Raio Inválido");
                txtRaio.Focus();
                
            } else if(!Double.TryParse(txtAltura.Text, out altura) || altura <= 0)
            {
                MessageBox.Show("Altura Inválida");
                txtAltura.Focus();
            } else
            {
                volume = Math.PI * Math.Pow(raio, 2) * altura;
                txtVolume.Text = volume.ToString("N2");
            }
        }

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtRaio.Text, out raio) || raio <= 0)
            {
                MessageBox.Show("raio inválido!");
            }
        }
    }
}
