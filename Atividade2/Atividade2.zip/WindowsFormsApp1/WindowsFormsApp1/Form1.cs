﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);

            }
            catch
            {
                errorProvider2.SetError(txtNumero2, "Número 2 inválido!");
                txtNumero2.Focus();
            }
        }

        private void btnAdd_Validated(object sender, EventArgs e)
        {
            
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = Convert.ToDouble(txtNumero1.Text) - Convert.ToDouble(txtNumero2.Text);
            txtResultado.Text = resultado.ToString();
        }

        private void btnMulti_Click(object sender, EventArgs e)
        {
            resultado = Convert.ToDouble(txtNumero1.Text) * Convert.ToDouble(txtNumero2.Text);
            txtResultado.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (Convert.ToDouble(txtNumero2.Text) == 0)
            {
                MessageBox.Show("O número divisor deve ser maior que zero");
            }
            else
            {
                resultado = Convert.ToDouble(txtNumero1.Text) / Convert.ToDouble(txtNumero2.Text);
                txtResultado.Text = resultado.ToString();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = string.Empty;
            txtNumero2.Text = string.Empty;
            txtResultado.Text = string.Empty;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void button3_Click(object sender, EventArgs e)
                {
                    resultado = Convert.ToDouble(txtNumero2.Text) + Convert.ToDouble(txtNumero1.Text);
                    txtResultado.Text = resultado.ToString();
                }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                errorProvider1.SetError(txtNumero1, "Número inválido!");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }
    }
}
