﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Notas.Items.Clear();
            string[,] respostaAlunos = new string[7, 10];
            string[] gabarito = new string[10] { "A", "B", "C", "E", "A", "D", "B", "C", "E", "A" };

            for (int i = 0; i < respostaAlunos.GetLength(0); i++)
            {
                for (int j = 0; j < respostaAlunos.GetLength(1); j++)

                {
                    respostaAlunos[i, j] = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}", "Respostas").ToUpper();
                    if (respostaAlunos[i, j] != "A" && respostaAlunos[i, j] != "B" && respostaAlunos[i, j] != "C" && respostaAlunos[i, j] != "D" && respostaAlunos[i, j] != "E")
                    {
                        MessageBox.Show("Resposta inválida! Digite A, B, C, D ou E.");
                        j--;
                        continue;
                    }
                    if (respostaAlunos[i, j] == gabarito[j])
                    {
                        Notas.Items.Add($"Aluno {i + 1}, questão {j + 1}: Resposta correta!");
                    }
                    else
                    {
                        Notas.Items.Add($"Aluno {i + 1}, questão {j + 1}: Resposta incorreta!");
                    }
                }
            }
        }

        private void Notas_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}

